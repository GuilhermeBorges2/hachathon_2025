// lib/services/answer_sheet_processor.dart
import 'package:hackathon/models/question.dart';

class AnswerSheetProcessor {

  /// Processa o texto reconhecido pelo OCR e extrai as respostas
  static Map<String, String> processAnswerSheet(String recognizedText, List<Question> questions) {
    Map<String, String> detectedAnswers = {};

    // Limpa o texto removendo caracteres especiais desnecessários
    String cleanText = _cleanText(recognizedText);

    // Tenta diferentes padrões de reconhecimento
    List<Map<String, String>> patterns = [
      _extractPattern1(cleanText), // Padrão: "1. A", "2. B", etc.
      _extractPattern2(cleanText), // Padrão: "1) A", "2) B", etc.
      _extractPattern3(cleanText), // Padrão: "Q1: A", "Q2: B", etc.
      _extractPattern4(cleanText), // Padrão: "1 A", "2 B", etc.
      _extractPattern5(cleanText), // Padrão: linhas separadas
    ];

    // Combina os resultados dos diferentes padrões
    for (var patternResult in patterns) {
      for (var entry in patternResult.entries) {
        if (!detectedAnswers.containsKey(entry.key)) {
          detectedAnswers[entry.key] = entry.value;
        }
      }
    }

    // Mapeia números de questão para IDs de questão e letras para IDs de opção
    Map<String, String> finalAnswers = {};
    for (var entry in detectedAnswers.entries) {
      String questionNumber = entry.key;
      String answerLetter = entry.value;

      if (int.tryParse(questionNumber) != null) {
        int qNum = int.parse(questionNumber);
        if (qNum > 0 && qNum <= questions.length) {
          String questionId = questions[qNum - 1].id;
          String? optionId = _mapAnswerLetterToOptionId(questions[qNum - 1], answerLetter);

          if (optionId != null) {
            finalAnswers[questionId] = optionId;
          }
        }
      }
    }

    return finalAnswers;
  }

  /// Limpa o texto removendo caracteres desnecessários
  static String _cleanText(String text) {
    // Remove quebras de linha excessivas e normaliza espaços
    return text
        .replaceAll(RegExp(r'\n+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  /// Padrão 1: "1. A", "2. B", "3. C", etc.
  static Map<String, String> _extractPattern1(String text) {
    Map<String, String> answers = {};
    RegExp pattern = RegExp(r'(\d+)\.?\s*([A-D])', caseSensitive: false);
    Iterable<RegExpMatch> matches = pattern.allMatches(text);

    for (RegExpMatch match in matches) {
      String questionNumber = match.group(1)!;
      String answer = match.group(2)!.toUpperCase();
      answers[questionNumber] = answer;
    }

    return answers;
  }

  /// Padrão 2: "1) A", "2) B", "3) C", etc.
  static Map<String, String> _extractPattern2(String text) {
    Map<String, String> answers = {};
    RegExp pattern = RegExp(r'(\d+)\)\s*([A-D])', caseSensitive: false);
    Iterable<RegExpMatch> matches = pattern.allMatches(text);

    for (RegExpMatch match in matches) {
      String questionNumber = match.group(1)!;
      String answer = match.group(2)!.toUpperCase();
      answers[questionNumber] = answer;
    }

    return answers;
  }

  /// Padrão 3: "Q1: A", "Q2: B", "Q3: C", etc.
  static Map<String, String> _extractPattern3(String text) {
    Map<String, String> answers = {};
    RegExp pattern = RegExp(r'Q(\d+):?\s*([A-D])', caseSensitive: false);
    Iterable<RegExpMatch> matches = pattern.allMatches(text);

    for (RegExpMatch match in matches) {
      String questionNumber = match.group(1)!;
      String answer = match.group(2)!.toUpperCase();
      answers[questionNumber] = answer;
    }

    return answers;
  }

  /// Padrão 4: "1 A", "2 B", "3 C", etc. (sem pontuação)
  static Map<String, String> _extractPattern4(String text) {
    Map<String, String> answers = {};
    RegExp pattern = RegExp(r'(\d+)\s+([A-D])(?=\s|$)', caseSensitive: false);
    Iterable<RegExpMatch> matches = pattern.allMatches(text);

    for (RegExpMatch match in matches) {
      String questionNumber = match.group(1)!;
      String answer = match.group(2)!.toUpperCase();
      answers[questionNumber] = answer;
    }

    return answers;
  }

  /// Padrão 5: Linhas separadas (cada linha pode conter uma resposta)
  static Map<String, String> _extractPattern5(String text) {
    Map<String, String> answers = {};
    List<String> lines = text.split(RegExp(r'[\n\r]+'));

    for (int i = 0; i < lines.length; i++) {
      String line = lines[i].trim();

      // Procura por letras A, B, C, D isoladas na linha
      RegExp letterPattern = RegExp(r'\b([A-D])\b', caseSensitive: false);
      RegExpMatch? match = letterPattern.firstMatch(line);

      if (match != null) {
        String answer = match.group(1)!.toUpperCase();

        // Tenta encontrar um número na mesma linha ou nas linhas próximas
        RegExp numberPattern = RegExp(r'(\d+)');
        RegExpMatch? numberMatch = numberPattern.firstMatch(line);

        if (numberMatch != null) {
          String questionNumber = numberMatch.group(1)!;
          answers[questionNumber] = answer;
        } else {
          // Se não encontrou número na linha, assume que é sequencial
          String questionNumber = (i + 1).toString();
          answers[questionNumber] = answer;
        }
      }
    }

    return answers;
  }

  /// Mapeia a letra da resposta (A, B, C, D) para o ID da opção correspondente
  static String? _mapAnswerLetterToOptionId(Question question, String letter) {
    int letterIndex = letter.codeUnitAt(0) - 'A'.codeUnitAt(0);
    if (letterIndex >= 0 && letterIndex < question.options.length) {
      return question.options[letterIndex].id;
    }
    return null;
  }

  /// Valida se as respostas detectadas fazem sentido
  static Map<String, String> validateDetectedAnswers(
      Map<String, String> detectedAnswers,
      List<Question> questions
      ) {
    Map<String, String> validatedAnswers = {};

    for (var entry in detectedAnswers.entries) {
      String questionId = entry.key;
      String optionId = entry.value;

      // Verifica se a questão existe
      Question? question = questions.firstWhere(
            (q) => q.id == questionId,
        orElse: () => throw StateError('Questão não encontrada'),
      );

      // Verifica se a opção existe para esta questão
      bool optionExists = question.options.any((option) => option.id == optionId);

      if (optionExists) {
        validatedAnswers[questionId] = optionId;
      }
    }

    return validatedAnswers;
  }

  /// Calcula estatísticas de confiança da detecção
  static Map<String, dynamic> calculateDetectionStats(
      Map<String, String> detectedAnswers,
      List<Question> questions
      ) {
    int totalQuestions = questions.length;
    int detectedCount = detectedAnswers.length;
    double detectionRate = totalQuestions > 0 ? (detectedCount / totalQuestions) * 100 : 0;

    List<int> missingQuestions = [];
    for (int i = 0; i < questions.length; i++) {
      String questionId = questions[i].id;
      if (!detectedAnswers.containsKey(questionId)) {
        missingQuestions.add(i + 1); // Número da questão (1-based)
      }
    }

    return {
      'totalQuestions': totalQuestions,
      'detectedCount': detectedCount,
      'detectionRate': detectionRate,
      'missingQuestions': missingQuestions,
      'isComplete': missingQuestions.isEmpty,
    };
  }

  /// Gera sugestões para melhorar a detecção
  static List<String> generateImprovementSuggestions(Map<String, dynamic> stats) {
    List<String> suggestions = [];

    double detectionRate = stats['detectionRate'];
    List<int> missingQuestions = stats['missingQuestions'];

    if (detectionRate < 50) {
      suggestions.add('A qualidade da imagem pode estar baixa. Tente tirar uma foto mais nítida.');
      suggestions.add('Certifique-se de que a folha de resposta está bem iluminada.');
      suggestions.add('Verifique se o formato da folha de resposta é compatível (ex: 1. A, 2. B, etc.).');
    } else if (detectionRate < 80) {
      suggestions.add('Algumas respostas não foram detectadas. Verifique se todas estão claramente marcadas.');
      if (missingQuestions.isNotEmpty) {
        suggestions.add('Questões não detectadas: ${missingQuestions.join(', ')}');
      }
    } else if (detectionRate < 100) {
      suggestions.add('Quase todas as respostas foram detectadas! Verifique as questões em falta.');
      if (missingQuestions.isNotEmpty) {
        suggestions.add('Questões não detectadas: ${missingQuestions.join(', ')}');
      }
    } else {
      suggestions.add('Excelente! Todas as respostas foram detectadas com sucesso.');
    }

    return suggestions;
  }
}

