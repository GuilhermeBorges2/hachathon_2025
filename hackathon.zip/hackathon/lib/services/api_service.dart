// lib/services/api_service.dart
import 'package:hackathon/models/student.dart';
import 'package:hackathon/models/question.dart';
import 'package:hackathon/models/school_class.dart';
import 'package:hackathon/models/answer_key.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  static const String _baseUrl = 'http://sua-api-java.com/api'; // TODO: Substitua pela URL da sua API Java

  // Headers padrão para todas as requisições
  static Map<String, String> get _defaultHeaders => {
    'Content-Type': 'application/json; charset=UTF-8',
    'Accept': 'application/json',
  };

  static Future<List<SchoolClass>> fetchClasses() async {
    // TODO: Observação: Implementação real da API
    /*
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/classes'),
        headers: _defaultHeaders,
      );

      if (response.statusCode == 200) {
        List<dynamic> body = json.decode(response.body);
        return body.map((dynamic item) => SchoolClass.fromJson(item)).toList();
      } else {
        throw Exception('Falha ao carregar turmas da API: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erro de conexão ao buscar turmas: $e');
    }
    */

    await Future.delayed(const Duration(seconds: 1));
    return [
      SchoolClass(id: 'class_a', name: 'Turma A - Manhã'),
      SchoolClass(id: 'class_b', name: 'Turma B - Tarde'),
      SchoolClass(id: 'class_c', name: 'Turma C - Noite'),
    ];
  }

  static Future<List<Student>> fetchStudents({String? classId}) async {
    // TODO: Observação: Implementação real da API
    /*
    try {
      String url = '$_baseUrl/students';
      if (classId != null) {
        url += '?classId=$classId';
      }

      final response = await http.get(
        Uri.parse(url),
        headers: _defaultHeaders,
      );

      if (response.statusCode == 200) {
        List<dynamic> body = json.decode(response.body);
        return body.map((dynamic item) => Student.fromJson(item)).toList();
      } else {
        throw Exception('Falha ao carregar alunos da API: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erro de conexão ao buscar alunos: $e');
    }
    */

    await Future.delayed(const Duration(seconds: 1));

    final List<Student> allStudents = [
      Student(id: '1', name: 'João Silva', registration: '2023001', classId: 'class_a'),
      Student(id: '2', name: 'Maria Souza', registration: '2023002', classId: 'class_a'),
      Student(id: '3', name: 'Pedro Santos', registration: '2023003', classId: 'class_b'),
      Student(id: '4', name: 'Ana Costa', registration: '2023004', classId: 'class_b'),
      Student(id: '5', name: 'Carlos Lima', registration: '2023005', classId: 'class_c'),
      Student(id: '6', name: 'Fernanda Dias', registration: '2023006', classId: 'class_c'),
      Student(id: '7', name: 'Aluno OCR', registration: 'OCR123', classId: 'class_a'),
    ];

    if (classId != null) {
      return allStudents.where((student) => student.classId == classId).toList();
    }
    return allStudents;
  }

  // TODO: Observação: Endpoint para salvar gabarito
  static Future<void> saveAnswerKey(AnswerKey answerKey) async {
    final url = Uri.parse('$_baseUrl/answer-keys');
    print('Salvando gabarito para: $url');
    print('Dados do gabarito: ${json.encode(answerKey.toJson())}');

    try {
      final response = await http.post(
        url,
        headers: _defaultHeaders,
        body: json.encode(answerKey.toJson()),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        print('Gabarito salvo com sucesso! Resposta: ${response.body}');
      } else {
        print('Falha ao salvar gabarito. Status: ${response.statusCode}, Corpo: ${response.body}');
        throw Exception('Falha ao salvar gabarito na API: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print('Erro ao conectar ou salvar gabarito: $e');
      throw Exception('Erro de conexão ou salvamento: $e');
    }
  }

  // TODO: Observação: Endpoint para atualizar gabarito
  static Future<void> updateAnswerKey(AnswerKey answerKey) async {
    final url = Uri.parse('$_baseUrl/answer-keys/${answerKey.id}');
    print('Atualizando gabarito para: $url');
    print('Dados do gabarito: ${json.encode(answerKey.toJson())}');

    try {
      final response = await http.put(
        url,
        headers: _defaultHeaders,
        body: json.encode(answerKey.toJson()),
      );

      if (response.statusCode == 200) {
        print('Gabarito atualizado com sucesso! Resposta: ${response.body}');
      } else {
        print('Falha ao atualizar gabarito. Status: ${response.statusCode}, Corpo: ${response.body}');
        throw Exception('Falha ao atualizar gabarito na API: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print('Erro ao conectar ou atualizar gabarito: $e');
      throw Exception('Erro de conexão ou atualização: $e');
    }
  }

  // TODO: Observação: Endpoint para buscar gabarito por turma
  static Future<AnswerKey?> fetchAnswerKeyByClass(String classId) async {
    // Implementação real da API:
    /*
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/answer-keys/class/$classId'),
        headers: _defaultHeaders,
      );

      if (response.statusCode == 200) {
        return AnswerKey.fromJson(json.decode(response.body));
      } else if (response.statusCode == 404) {
        return null; // Gabarito não encontrado
      } else {
        throw Exception('Falha ao buscar gabarito: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erro de conexão ao buscar gabarito: $e');
    }
    */

    await Future.delayed(const Duration(seconds: 1));

    // Dados simulados de gabarito
    if (classId == 'class_a') {
      return AnswerKey(
        id: 'answer_key_1',
        examTitle: 'Prova de Flutter - 1º Bimestre',
        classId: classId,
        totalQuestions: 10,
        answers: {
          1: 'B', 2: 'C', 3: 'A', 4: 'D', 5: 'B',
          6: 'A', 7: 'C', 8: 'B', 9: 'D', 10: 'A',
        },
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        createdBy: 'professor',
      );
    }

    return null; // Gabarito não encontrado para outras turmas
  }

  // TODO: Observação: Endpoint para buscar todos os gabaritos
  static Future<List<AnswerKey>> fetchAllAnswerKeys() async {
    // Implementação real da API:
    /*
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/answer-keys'),
        headers: _defaultHeaders,
      );

      if (response.statusCode == 200) {
        List<dynamic> body = json.decode(response.body);
        return body.map((dynamic item) => AnswerKey.fromJson(item)).toList();
      } else {
        throw Exception('Falha ao carregar gabaritos: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Erro de conexão ao buscar gabaritos: $e');
    }
    */

    await Future.delayed(const Duration(seconds: 1));

    // Dados simulados
    return [
      AnswerKey(
        id: 'answer_key_1',
        examTitle: 'Prova de Flutter - 1º Bimestre',
        classId: 'class_a',
        totalQuestions: 10,
        answers: {
          1: 'B', 2: 'C', 3: 'A', 4: 'D', 5: 'B',
          6: 'A', 7: 'C', 8: 'B', 9: 'D', 10: 'A',
        },
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        createdBy: 'professor',
      ),
    ];
  }

  // TODO: Observação: Endpoint para envio de avaliações corrigidas com gabarito
  static Future<void> submitEvaluationWithAnswerKey(
      String studentId,
      String answerKeyId,
      Map<int, String> studentAnswers,
      Map<String, dynamic> additionalData,
      ) async {
    final url = Uri.parse('$_baseUrl/evaluations/with-answer-key');

    final evaluationData = {
      'studentId': studentId,
      'answerKeyId': answerKeyId,
      'studentAnswers': studentAnswers.map((key, value) => MapEntry(key.toString(), value)),
      'timestamp': DateTime.now().toIso8601String(),
      'correctionMethod': additionalData['correctionMethod'] ?? 'OCR',
      'detectionStats': additionalData['detectionStats'],
      'recognizedText': additionalData['recognizedText'],
    };

    print('Enviando avaliação com gabarito para: $url');
    print('Dados da avaliação: ${json.encode(evaluationData)}');

    try {
      final response = await http.post(
        url,
        headers: _defaultHeaders,
        body: json.encode(evaluationData),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        print('Avaliação com gabarito enviada com sucesso! Resposta: ${response.body}');
      } else {
        print('Falha ao enviar avaliação. Status: ${response.statusCode}, Corpo: ${response.body}');
        throw Exception('Falha ao enviar avaliação para a API: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print('Erro ao conectar ou enviar dados: $e');
      throw Exception('Erro de conexão ou envio: $e');
    }
  }

  // Métodos existentes mantidos para compatibilidade
  static Future<List<Question>> fetchQuestions() async {
    await Future.delayed(const Duration(seconds: 1));

    final List<Map<String, dynamic>> rawQuestions = [
      {
        'id': 'q1',
        'text': 'Qual o principal objetivo do Flutter?',
        'options': [
          {'id': 'o1a', 'text': 'Desenvolver aplicativos apenas para Android'},
          {'id': 'o1b', 'text': 'Desenvolver aplicativos multiplataforma com uma única base de código'},
          {'id': 'o1c', 'text': 'Desenvolver websites estáticos'},
          {'id': 'o1d', 'text': 'Desenvolver jogos 3D'},
        ],
        'correctAnswerId': 'o1b',
      },
      {
        'id': 'q2',
        'text': 'Qual linguagem de programação é utilizada no Flutter?',
        'options': [
          {'id': 'o2a', 'text': 'Java'},
          {'id': 'o2b', 'text': 'Kotlin'},
          {'id': 'o2c', 'text': 'Dart'},
          {'id': 'o2d', 'text': 'Swift'},
        ],
        'correctAnswerId': 'o2c',
      },
      {
        'id': 'q3',
        'text': 'Qual widget é usado para layout em Flutter?',
        'options': [
          {'id': 'o3a', 'text': 'TextView'},
          {'id': 'o3b', 'text': 'LinearLayout'},
          {'id': 'o3c', 'text': 'Container'},
          {'id': 'o3d', 'text': 'Activity'},
        ],
        'correctAnswerId': 'o3c',
      },
    ];

    return rawQuestions.map((json) => Question.fromJson(json)).toList();
  }

  static Future<void> submitEvaluation(String studentId, Map<String, dynamic> evaluationData) async {
    final url = Uri.parse('$_baseUrl/evaluations');
    print('Enviando avaliação para: $url');
    print('Dados da avaliação: ${json.encode(evaluationData)}');

    try {
      final response = await http.post(
        url,
        headers: _defaultHeaders,
        body: json.encode(evaluationData),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        print('Avaliação enviada com sucesso! Resposta: ${response.body}');
      } else {
        print('Falha ao enviar avaliação. Status: ${response.statusCode}, Corpo: ${response.body}');
        throw Exception('Falha ao enviar avaliação para a API: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print('Erro ao conectar ou enviar dados: $e');
      throw Exception('Erro de conexão ou envio: $e');
    }
  }
}

// Extensão para adicionar firstWhereOrNull, útil para buscar em listas
extension IterableExtension<T> on Iterable<T> {
  T? firstWhereOrNull(bool Function(T element) test) {
    for (var element in this) {
      if (test(element)) {
        return element;
      }
    }
    return null;
  }
}

