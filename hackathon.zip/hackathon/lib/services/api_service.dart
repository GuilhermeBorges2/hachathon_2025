// lib/services/api_service.dart
import 'package:hackathon/models/student.dart';
// import 'package:http/http.dart' as http; // Você precisará adicionar a dependência http no pubspec.yaml

class ApiService {
  static const String _baseUrl = 'http://sua-api-java.com/api'; // TODO: Substitua pela URL da sua API Java

// TODO: Observação: Exemplo de como seria uma função para buscar alunos da API.
// Você precisará adicionar a dependência 'http' no seu pubspec.yaml para usar isso.
/*
  static Future<List<Student>> fetchStudents( ) async {
    final response = await http.get(Uri.parse('$_baseUrl/students' ));

    if (response.statusCode == 200) {
      List<dynamic> body = json.decode(response.body);
      return body.map((dynamic item) => Student.fromJson(item)).toList();
    } else {
      throw Exception('Falha ao carregar alunos da API');
    }
  }
  */

// TODO: Observação: Exemplo de como seria uma função para enviar avaliações para a API.
/*
  static Future<void> submitEvaluation(String studentId, Map<String, dynamic> evaluationData) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/evaluations' ),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode({
        'studentId': studentId,
        'evaluationData': evaluationData,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Falha ao enviar avaliação para a API');
    }
  }
  */
}

