// lib/models/answer_key.dart
class AnswerKey {
  final String id;
  final String examTitle;
  final String classId;
  final int totalQuestions;
  final Map<int, String> answers; // Map<QuestionNumber, CorrectAnswer>
  final DateTime createdAt;
  final String createdBy;

  AnswerKey({
    required this.id,
    required this.examTitle,
    required this.classId,
    required this.totalQuestions,
    required this.answers,
    required this.createdAt,
    required this.createdBy,
  });

  factory AnswerKey.fromJson(Map<String, dynamic> json) {
    Map<int, String> answersMap = {};
    if (json['answers'] != null) {
      Map<String, dynamic> answersJson = json['answers'];
      answersJson.forEach((key, value) {
        answersMap[int.parse(key)] = value;
      });
    }

    return AnswerKey(
      id: json['id'],
      examTitle: json['examTitle'],
      classId: json['classId'],
      totalQuestions: json['totalQuestions'],
      answers: answersMap,
      createdAt: DateTime.parse(json['createdAt']),
      createdBy: json['createdBy'],
    );
  }

  Map<String, dynamic> toJson() {
    Map<String, String> answersJson = {};
    answers.forEach((key, value) {
      answersJson[key.toString()] = value;
    });

    return {
      'id': id,
      'examTitle': examTitle,
      'classId': classId,
      'totalQuestions': totalQuestions,
      'answers': answersJson,
      'createdAt': createdAt.toIso8601String(),
      'createdBy': createdBy,
    };
  }

  // Método para verificar se o gabarito está completo
  bool get isComplete {
    if (answers.length != totalQuestions) return false;

    for (int i = 1; i <= totalQuestions; i++) {
      if (!answers.containsKey(i) || answers[i]!.isEmpty) {
        return false;
      }
    }
    return true;
  }

  // Método para obter questões em falta
  List<int> get missingQuestions {
    List<int> missing = [];
    for (int i = 1; i <= totalQuestions; i++) {
      if (!answers.containsKey(i) || answers[i]!.isEmpty) {
        missing.add(i);
      }
    }
    return missing;
  }

  // Método para calcular pontuação baseada nas respostas do aluno
  Map<String, dynamic> calculateScore(Map<int, String> studentAnswers) {
    int correctCount = 0;
    int totalAnswered = studentAnswers.length;
    List<Map<String, dynamic>> detailedResults = [];

    for (int questionNumber = 1; questionNumber <= totalQuestions; questionNumber++) {
      String? correctAnswer = answers[questionNumber];
      String? studentAnswer = studentAnswers[questionNumber];
      bool isCorrect = (studentAnswer != null && studentAnswer == correctAnswer);

      if (isCorrect) {
        correctCount++;
      }

      detailedResults.add({
        'questionNumber': questionNumber,
        'correctAnswer': correctAnswer,
        'studentAnswer': studentAnswer,
        'isCorrect': isCorrect,
        'wasAnswered': studentAnswer != null,
      });
    }

    double score = totalQuestions > 0 ? (correctCount / totalQuestions) * 100 : 0.0;

    return {
      'totalQuestions': totalQuestions,
      'correctAnswers': correctCount,
      'totalAnswered': totalAnswered,
      'score': score,
      'detailedResults': detailedResults,
      'isApproved': score >= 70.0, // Critério de aprovação
    };
  }

  // Cria uma cópia do gabarito com modificações
  AnswerKey copyWith({
    String? id,
    String? examTitle,
    String? classId,
    int? totalQuestions,
    Map<int, String>? answers,
    DateTime? createdAt,
    String? createdBy,
  }) {
    return AnswerKey(
      id: id ?? this.id,
      examTitle: examTitle ?? this.examTitle,
      classId: classId ?? this.classId,
      totalQuestions: totalQuestions ?? this.totalQuestions,
      answers: answers ?? Map.from(this.answers),
      createdAt: createdAt ?? this.createdAt,
      createdBy: createdBy ?? this.createdBy,
    );
  }
}

