// lib/models/question.dart
class Question {
  final String id;
  final String text;
  final List<AnswerOption> options;
  final String? correctAnswerId; // Adicionado para o gabarito

  Question({
    required this.id,
    required this.text,
    required this.options,
    this.correctAnswerId, // Pode ser nulo se não houver gabarito definido
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    var optionsList = json['options'] as List;
    List<AnswerOption> options = optionsList.map((i) => AnswerOption.fromJson(i)).toList();

    return Question(
      id: json['id'],
      text: json['text'],
      options: options,
      correctAnswerId: json['correctAnswerId'], // Mapeia o campo do JSON
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'text': text,
      'options': options.map((e) => e.toJson()).toList(),
      'correctAnswerId': correctAnswerId,
    };
  }
}

// AnswerOption permanece o mesmo
class AnswerOption {
  final String id;
  final String text;

  AnswerOption({
    required this.id,
    required this.text,
  });

  factory AnswerOption.fromJson(Map<String, dynamic> json) {
    return AnswerOption(
      id: json['id'],
      text: json['text'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'text': text,
    };
  }
}

