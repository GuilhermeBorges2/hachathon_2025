// lib/models/student.dart
class Student {
  final String id;
  final String name;
  final String registration;

  Student({
    required this.id,
    required this.name,
    required this.registration,
  });

  // Método para criar um Student a partir de um JSON (útil para API)
  factory Student.fromJson(Map<String, dynamic> json) {
    return Student(
      id: json['id'],
      name: json['name'],
      registration: json['registration'],
    );
  }

  // Método para converter um Student para JSON (útil para enviar para API)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'registration': registration,
    };
  }
}

