// lib/models/student.dart
class Student {
  final String id;
  final String name;
  final String registration;
  final String classId; // Adicionado para associar o aluno a uma turma

  Student({
    required this.id,
    required this.name,
    required this.registration,
    required this.classId, // Agora é obrigatório
  });

  factory Student.fromJson(Map<String, dynamic> json) {
    return Student(
      id: json['id'],
      name: json['name'],
      registration: json['registration'],
      classId: json['classId'], // Mapeia o campo do JSON
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'registration': registration,
      'classId': classId,
    };
  }
}

