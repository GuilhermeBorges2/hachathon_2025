// lib/screens/answer_key_definition_screen.dart
import 'package:flutter/material.dart';
import 'package:hackathon/models/answer_key.dart';
import 'package:hackathon/models/school_class.dart';
import 'package:hackathon/services/api_service.dart';
import 'package:hackathon/widgets/custom_button.dart';

class AnswerKeyDefinitionScreen extends StatefulWidget {
  final SchoolClass schoolClass;
  final AnswerKey? existingAnswerKey; // Para editar um gabarito existente

  const AnswerKeyDefinitionScreen({
    super.key,
    required this.schoolClass,
    this.existingAnswerKey,
  });

  @override
  State<AnswerKeyDefinitionScreen> createState() => _AnswerKeyDefinitionScreenState();
}

class _AnswerKeyDefinitionScreenState extends State<AnswerKeyDefinitionScreen> {
  final TextEditingController _examTitleController = TextEditingController();
  final TextEditingController _totalQuestionsController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  Map<int, String> _answers = {}; // Map<QuestionNumber, CorrectAnswer>
  int _totalQuestions = 10; // Valor padrão
  bool _isLoading = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _initializeForm();
  }

  void _initializeForm() {
    if (widget.existingAnswerKey != null) {
      // Editando um gabarito existente
      final answerKey = widget.existingAnswerKey!;
      _examTitleController.text = answerKey.examTitle;
      _totalQuestionsController.text = answerKey.totalQuestions.toString();
      _totalQuestions = answerKey.totalQuestions;
      _answers = Map.from(answerKey.answers);
    } else {
      // Criando um novo gabarito
      _examTitleController.text = 'Prova ${widget.schoolClass.name}';
      _totalQuestionsController.text = _totalQuestions.toString();
      _initializeAnswers();
    }
  }

  void _initializeAnswers() {
    _answers.clear();
    for (int i = 1; i <= _totalQuestions; i++) {
      _answers[i] = ''; // Inicializa vazio
    }
  }

  void _onTotalQuestionsChanged() {
    if (_totalQuestionsController.text.isNotEmpty) {
      int? newTotal = int.tryParse(_totalQuestionsController.text);
      if (newTotal != null && newTotal > 0 && newTotal <= 100) {
        setState(() {
          _totalQuestions = newTotal;

          // Ajusta o mapa de respostas
          Map<int, String> newAnswers = {};
          for (int i = 1; i <= _totalQuestions; i++) {
            newAnswers[i] = _answers[i] ?? ''; // Mantém resposta existente ou vazio
          }
          _answers = newAnswers;
        });
      }
    }
  }

  void _setAnswer(int questionNumber, String answer) {
    setState(() {
      _answers[questionNumber] = answer;
    });
  }

  Future<void> _saveAnswerKey() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // Verifica se todas as questões foram respondidas
    List<int> missingQuestions = [];
    for (int i = 1; i <= _totalQuestions; i++) {
      if (_answers[i] == null || _answers[i]!.isEmpty) {
        missingQuestions.add(i);
      }
    }

    if (missingQuestions.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Por favor, defina as respostas para as questões: ${missingQuestions.join(', ')}'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      final answerKey = AnswerKey(
        id: widget.existingAnswerKey?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
        examTitle: _examTitleController.text.trim(),
        classId: widget.schoolClass.id,
        totalQuestions: _totalQuestions,
        answers: Map.from(_answers),
        createdAt: widget.existingAnswerKey?.createdAt ?? DateTime.now(),
        createdBy: 'professor', // TODO: Pegar do usuário logado
      );

      if (widget.existingAnswerKey != null) {
        await ApiService.updateAnswerKey(answerKey);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gabarito atualizado com sucesso!'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        await ApiService.saveAnswerKey(answerKey);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gabarito salvo com sucesso!'),
            backgroundColor: Colors.green,
          ),
        );
      }

      Navigator.of(context).pop(answerKey); // Retorna o gabarito salvo
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erro ao salvar gabarito: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() {
        _isSaving = false;
      });
    }
  }

  void _showPreview() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Prévia do Gabarito'),
          content: SizedBox(
            width: double.maxFinite,
            height: 300,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Prova: ${_examTitleController.text}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text('Turma: ${widget.schoolClass.name}'),
                  Text('Total de Questões: $_totalQuestions'),
                  const SizedBox(height: 16),
                  const Text(
                    'Gabarito:',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: List.generate(_totalQuestions, (index) {
                      int questionNumber = index + 1;
                      String answer = _answers[questionNumber] ?? '';
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: answer.isEmpty ? Colors.red.shade100 : Colors.green.shade100,
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(
                            color: answer.isEmpty ? Colors.red : Colors.green,
                          ),
                        ),
                        child: Text(
                          '$questionNumber. ${answer.isEmpty ? '?' : answer}',
                          style: TextStyle(
                            color: answer.isEmpty ? Colors.red.shade700 : Colors.green.shade700,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      );
                    }),
                  ),
                ],
              ),
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Fechar'),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existingAnswerKey != null ? 'Editar Gabarito' : 'Definir Gabarito'),
        actions: [
          IconButton(
            icon: const Icon(Icons.preview),
            onPressed: _showPreview,
            tooltip: 'Prévia do Gabarito',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Informações da turma
              Card(
                color: Colors.blue.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Turma: ${widget.schoolClass.name}',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Defina o gabarito da prova para esta turma. Este gabarito será usado na correção automática via OCR.',
                        style: TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Título da prova
              TextFormField(
                controller: _examTitleController,
                decoration: const InputDecoration(
                  labelText: 'Título da Prova',
                  hintText: 'Ex: Prova de Matemática - 1º Bimestre',
                  prefixIcon: Icon(Icons.title),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Por favor, insira o título da prova';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 16),

              // Total de questões
              TextFormField(
                controller: _totalQuestionsController,
                decoration: const InputDecoration(
                  labelText: 'Total de Questões',
                  hintText: 'Ex: 10',
                  prefixIcon: Icon(Icons.format_list_numbered),
                ),
                keyboardType: TextInputType.number,
                onChanged: (value) => _onTotalQuestionsChanged(),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira o total de questões';
                  }
                  int? total = int.tryParse(value);
                  if (total == null || total <= 0 || total > 100) {
                    return 'Insira um número entre 1 e 100';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 24),

              // Seção de definição das respostas
              const Text(
                'Gabarito das Questões:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Selecione a alternativa correta para cada questão:',
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),

              const SizedBox(height: 16),

              // Grid de questões
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 3,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: _totalQuestions,
                itemBuilder: (context, index) {
                  int questionNumber = index + 1;
                  String currentAnswer = _answers[questionNumber] ?? '';

                  return Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Questão $questionNumber',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: ['A', 'B', 'C', 'D'].map((option) {
                              bool isSelected = currentAnswer == option;
                              return GestureDetector(
                                onTap: () => _setAnswer(questionNumber, option),
                                child: Container(
                                  width: 32,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    color: isSelected ? Colors.blue : Colors.grey.shade200,
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                      color: isSelected ? Colors.blue : Colors.grey,
                                      width: 2,
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      option,
                                      style: TextStyle(
                                        color: isSelected ? Colors.white : Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

              const SizedBox(height: 24),

              // Botões de ação
              Row(
                children: [
                  Expanded(
                    child: CustomButton(
                      text: 'Prévia',
                      icon: Icons.preview,
                      onPressed: _showPreview,
                      backgroundColor: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    flex: 2,
                    child: CustomButton(
                      text: _isSaving
                          ? 'Salvando...'
                          : (widget.existingAnswerKey != null ? 'Atualizar Gabarito' : 'Salvar Gabarito'),
                      icon: _isSaving ? null : Icons.save,
                      onPressed: _isSaving ? () {} : _saveAnswerKey,
                      backgroundColor: Colors.green,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _examTitleController.dispose();
    _totalQuestionsController.dispose();
    super.dispose();
  }
}

