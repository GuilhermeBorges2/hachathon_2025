// lib/screens/class_selection_screen.dart
import 'package:flutter/material.dart';
import 'package:hackathon/models/school_class.dart';
import 'package:hackathon/services/api_service.dart';
import 'package:hackathon/screens/student_selection_screen.dart';
import 'package:hackathon/screens/answer_key_definition_screen.dart';

class ClassSelectionScreen extends StatefulWidget {
  const ClassSelectionScreen({super.key});

  @override
  State<ClassSelectionScreen> createState() => _ClassSelectionScreenState();
}

class _ClassSelectionScreenState extends State<ClassSelectionScreen> {
  List<SchoolClass> _classes = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchClasses();
  }

  Future<void> _fetchClasses() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      final fetchedClasses = await ApiService.fetchClasses();
      setState(() {
        _classes = fetchedClasses;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Erro ao carregar turmas: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  void _showClassOptions(SchoolClass schoolClass) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                schoolClass.name,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'O que você gostaria de fazer?',
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),

              // Opção 1: Definir Gabarito
              ListTile(
                leading: const Icon(Icons.assignment, color: Colors.blue, size: 30),
                title: const Text('Definir Gabarito'),
                subtitle: const Text('Criar ou editar o gabarito da prova'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AnswerKeyDefinitionScreen(schoolClass: schoolClass),
                    ),
                  );
                },
              ),

              const Divider(),

              // Opção 2: Corrigir Provas
              ListTile(
                leading: const Icon(Icons.camera_alt, color: Colors.green, size: 30),
                title: const Text('Corrigir Provas'),
                subtitle: const Text('Selecionar aluno e corrigir prova'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => StudentSelectionScreen(classId: schoolClass.id),
                    ),
                  );
                },
              ),

              const SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Selecionar Turma'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.red, fontSize: 16),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _fetchClasses,
                child: const Text('Tentar Novamente'),
              ),
            ],
          ),
        ),
      )
          : _classes.isEmpty
          ? const Center(
        child: Text(
          'Nenhuma turma encontrada.',
          style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
      )
          : Column(
        children: [
          // Instruções
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16.0),
            color: Colors.blue.shade50,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Selecione uma turma:',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Você pode definir o gabarito da prova ou corrigir provas dos alunos.',
                  style: TextStyle(fontSize: 14, color: Colors.grey),
                ),
              ],
            ),
          ),

          // Lista de turmas
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(8.0),
              itemCount: _classes.length,
              itemBuilder: (context, index) {
                final schoolClass = _classes[index];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 8.0),
                  elevation: 3,
                  child: ListTile(
                    leading: const Icon(Icons.group, size: 40, color: Colors.blueAccent),
                    title: Text(
                      schoolClass.name,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: const Text('Toque para ver opções'),
                    trailing: const Icon(Icons.more_vert),
                    onTap: () => _showClassOptions(schoolClass),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

