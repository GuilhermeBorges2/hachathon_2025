// lib/screens/student_selection_screen.dart
import 'package:flutter/material.dart';
import 'package:hackathon/models/student.dart'; // Vamos criar este modelo em breve
import 'package:hackathon/services/api_service.dart'; // Vamos criar este serviço em breve
import 'package:hackathon/screens/evaluation_screen.dart'; // Vamos criar esta tela em breve

class StudentSelectionScreen extends StatefulWidget {
  const StudentSelectionScreen({super.key});

  @override
  State<StudentSelectionScreen> createState() => _StudentSelectionScreenState();
}

class _StudentSelectionScreenState extends State<StudentSelectionScreen> {
  List<Student> _students = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchStudents();
  }

  Future<void> _fetchStudents() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      // TODO: Observação: Aqui é onde você faria a chamada à API Java para buscar a lista de alunos.
      // Por enquanto, vamos simular uma lista de alunos.
      // final List<Student> fetchedStudents = await ApiService.fetchStudents();
      await Future.delayed(const Duration(seconds: 2)); // Simula atraso da rede

      final List<Student> fetchedStudents = [
        Student(id: '1', name: 'João Silva', registration: '2023001'),
        Student(id: '2', name: 'Maria Souza', registration: '2023002'),
        Student(id: '3', name: 'Pedro Santos', registration: '2023003'),
        Student(id: '4', name: 'Ana Costa', registration: '2023004'),
      ];

      setState(() {
        _students = fetchedStudents;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Erro ao carregar alunos: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Selecionar Aluno'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.red, fontSize: 16),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _fetchStudents,
                child: const Text('Tentar Novamente'),
              ),
            ],
          ),
        ),
      )
          : _students.isEmpty
          ? const Center(
        child: Text(
          'Nenhum aluno encontrado.',
          style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(8.0),
        itemCount: _students.length,
        itemBuilder: (context, index) {
          final student = _students[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8.0),
            child: ListTile(
              leading: const Icon(Icons.person, size: 40, color: Colors.blueAccent),
              title: Text(
                student.name,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text('Matrícula: ${student.registration}'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                // TODO: Navegar para a tela de avaliação com o aluno selecionado
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EvaluationScreen(student: student),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

