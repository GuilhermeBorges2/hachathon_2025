// lib/screens/student_selection_screen.dart
import 'package:flutter/material.dart';
import 'package:hackathon/models/student.dart';
import 'package:hackathon/services/api_service.dart';
import 'package:hackathon/screens/evaluation_screen.dart';
import 'package:hackathon/widgets/custom_button.dart'; // Certifique-se de que este import está correto

class StudentSelectionScreen extends StatefulWidget {
  final String classId; // Agora recebe o ID da turma

  const StudentSelectionScreen({super.key, required this.classId});

  @override
  State<StudentSelectionScreen> createState() => _StudentSelectionScreenState();
}

class _StudentSelectionScreenState extends State<StudentSelectionScreen> {
  List<Student> _students = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchStudents();
  }

  Future<void> _fetchStudents() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      // Passa o classId para o fetchStudents
      final List<Student> fetchedStudents = await ApiService.fetchStudents(classId: widget.classId);
      setState(() {
        _students = fetchedStudents;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Erro ao carregar alunos: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Selecionar Aluno'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator()) // Conteúdo quando está carregando
          : _errorMessage != null
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.red, fontSize: 16),
              ),
              const SizedBox(height: 20),
              CustomButton( // Usando o CustomButton
                text: 'Tentar Novamente',
                onPressed: _fetchStudents,
              ),
            ],
          ),
        ),
      )
          : _students.isEmpty
          ? const Center(
        child: Text(
          'Nenhum aluno encontrado para esta turma.',
          style: TextStyle(fontSize: 18, color: Colors.grey),
          textAlign: TextAlign.center,
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(8.0),
        itemCount: _students.length,
        itemBuilder: (context, index) {
          final student = _students[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8.0),
            child: ListTile(
              leading: const Icon(Icons.person, size: 40, color: Colors.blueAccent),
              title: Text(
                student.name,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text('Matrícula: ${student.registration}'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EvaluationScreen(student: student),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

