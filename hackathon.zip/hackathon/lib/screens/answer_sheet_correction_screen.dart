// lib/screens/answer_sheet_correction_screen.dart
import 'package:flutter/material.dart';
import 'package:hackathon/models/student.dart';
import 'package:hackathon/models/answer_key.dart';
import 'package:hackathon/services/api_service.dart';
import 'package:hackathon/services/answer_sheet_processor.dart';
import 'package:hackathon/widgets/custom_button.dart';

// Importações para ImagePicker e ML Kit
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'dart:io';

class AnswerSheetCorrectionScreen extends StatefulWidget {
  final Student student;

  const AnswerSheetCorrectionScreen({super.key, required this.student});

  @override
  State<AnswerSheetCorrectionScreen> createState() => _AnswerSheetCorrectionScreenState();
}

class _AnswerSheetCorrectionScreenState extends State<AnswerSheetCorrectionScreen> {
  AnswerKey? _answerKey;
  Map<int, String> _detectedAnswers = {}; // Map<QuestionNumber, DetectedAnswer>
  Map<String, dynamic> _detectionStats = {};
  List<String> _suggestions = [];
  bool _isLoading = true;
  bool _isProcessingImage = false;
  String? _errorMessage;
  File? _capturedImage;
  String _recognizedText = '';

  final ImagePicker _picker = ImagePicker();
  final TextRecognizer _textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);

  @override
  void initState() {
    super.initState();
    _fetchAnswerKey();
  }

  @override
  void dispose() {
    _textRecognizer.close();
    super.dispose();
  }

  Future<void> _fetchAnswerKey() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      final answerKey = await ApiService.fetchAnswerKeyByClass(widget.student.classId);

      if (answerKey == null) {
        setState(() {
          _errorMessage = 'Nenhum gabarito foi definido para esta turma. '
              'Por favor, defina o gabarito antes de corrigir as provas.';
          _isLoading = false;
        });
        return;
      }

      setState(() {
        _answerKey = answerKey;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Erro ao carregar gabarito: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  Future<void> _scanAnswerSheet() async {
    if (_answerKey == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gabarito não carregado. Tente novamente.')),
      );
      return;
    }

    try {
      final ImageSource? source = await _showImageSourceDialog();
      if (source == null) return;

      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 90,
        maxWidth: 1920,
        maxHeight: 1920,
      );

      if (pickedFile != null) {
        setState(() {
          _isProcessingImage = true;
          _capturedImage = File(pickedFile.path);
          _recognizedText = '';
          _detectedAnswers = {};
          _detectionStats = {};
          _suggestions = [];
        });

        final InputImage inputImage = InputImage.fromFilePath(pickedFile.path);
        final RecognizedText recognizedText = await _textRecognizer.processImage(inputImage);

        _recognizedText = recognizedText.text;
        print('Texto reconhecido: $_recognizedText');

        // Processa o texto para extrair respostas usando o número de questões do gabarito
        Map<int, String> detectedAnswers = _processAnswerSheetWithAnswerKey(_recognizedText);

        // Calcula estatísticas de detecção
        Map<String, dynamic> stats = _calculateDetectionStats(detectedAnswers);

        // Gera sugestões para melhorar a detecção
        List<String> suggestions = _generateImprovementSuggestions(stats);

        setState(() {
          _detectedAnswers = detectedAnswers;
          _detectionStats = stats;
          _suggestions = suggestions;
          _isProcessingImage = false;
        });

        _showDetectionResultsSnackBar();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao escanear folha de resposta: ${e.toString()}')),
      );
      setState(() {
        _isProcessingImage = false;
      });
    }
  }

  Map<int, String> _processAnswerSheetWithAnswerKey(String recognizedText) {
    Map<int, String> detectedAnswers = {};

    // Limpa o texto
    String cleanText = recognizedText
        .replaceAll(RegExp(r'\n+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    // Tenta diferentes padrões de reconhecimento
    List<RegExp> patterns = [
      RegExp(r'(\d+)\.?\s*([A-D])', caseSensitive: false), // "1. A", "2. B"
      RegExp(r'(\d+)\)\s*([A-D])', caseSensitive: false),  // "1) A", "2) B"
      RegExp(r'Q(\d+):?\s*([A-D])', caseSensitive: false), // "Q1: A", "Q2: B"
      RegExp(r'(\d+)\s+([A-D])(?=\s|$)', caseSensitive: false), // "1 A", "2 B"
    ];

    for (RegExp pattern in patterns) {
      Iterable<RegExpMatch> matches = pattern.allMatches(cleanText);

      for (RegExpMatch match in matches) {
        String questionNumberStr = match.group(1)!;
        String answer = match.group(2)!.toUpperCase();

        int? questionNumber = int.tryParse(questionNumberStr);
        if (questionNumber != null &&
            questionNumber >= 1 &&
            questionNumber <= _answerKey!.totalQuestions) {
          detectedAnswers[questionNumber] = answer;
        }
      }
    }

    return detectedAnswers;
  }

  Map<String, dynamic> _calculateDetectionStats(Map<int, String> detectedAnswers) {
    int totalQuestions = _answerKey!.totalQuestions;
    int detectedCount = detectedAnswers.length;
    double detectionRate = totalQuestions > 0 ? (detectedCount / totalQuestions) * 100 : 0;

    List<int> missingQuestions = [];
    for (int i = 1; i <= totalQuestions; i++) {
      if (!detectedAnswers.containsKey(i)) {
        missingQuestions.add(i);
      }
    }

    return {
      'totalQuestions': totalQuestions,
      'detectedCount': detectedCount,
      'detectionRate': detectionRate,
      'missingQuestions': missingQuestions,
      'isComplete': missingQuestions.isEmpty,
    };
  }

  List<String> _generateImprovementSuggestions(Map<String, dynamic> stats) {
    List<String> suggestions = [];

    double detectionRate = stats['detectionRate'];
    List<int> missingQuestions = stats['missingQuestions'];

    if (detectionRate < 50) {
      suggestions.add('A qualidade da imagem pode estar baixa. Tente tirar uma foto mais nítida.');
      suggestions.add('Certifique-se de que a folha de resposta está bem iluminada.');
      suggestions.add('Verifique se o formato da folha de resposta é compatível (ex: 1. A, 2. B, etc.).');
    } else if (detectionRate < 80) {
      suggestions.add('Algumas respostas não foram detectadas. Verifique se todas estão claramente marcadas.');
      if (missingQuestions.isNotEmpty) {
        suggestions.add('Questões não detectadas: ${missingQuestions.join(', ')}');
      }
    } else if (detectionRate < 100) {
      suggestions.add('Quase todas as respostas foram detectadas! Verifique as questões em falta.');
      if (missingQuestions.isNotEmpty) {
        suggestions.add('Questões não detectadas: ${missingQuestions.join(', ')}');
      }
    } else {
      suggestions.add('Excelente! Todas as respostas foram detectadas com sucesso.');
    }

    return suggestions;
  }

  Future<ImageSource?> _showImageSourceDialog() async {
    return await showDialog<ImageSource>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Selecionar Fonte da Imagem'),
          content: const Text('Como você gostaria de obter a imagem da folha de resposta?'),
          actions: <Widget>[
            TextButton(
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.camera_alt),
                  SizedBox(width: 8),
                  Text('Câmera'),
                ],
              ),
              onPressed: () => Navigator.of(context).pop(ImageSource.camera),
            ),
            TextButton(
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.photo_library),
                  SizedBox(width: 8),
                  Text('Galeria'),
                ],
              ),
              onPressed: () => Navigator.of(context).pop(ImageSource.gallery),
            ),
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        );
      },
    );
  }

  void _showDetectionResultsSnackBar() {
    if (_detectionStats.isNotEmpty) {
      int detectedCount = _detectionStats['detectedCount'];
      int totalQuestions = _detectionStats['totalQuestions'];
      double detectionRate = _detectionStats['detectionRate'];

      Color backgroundColor;
      if (detectionRate >= 90) {
        backgroundColor = Colors.green;
      } else if (detectionRate >= 70) {
        backgroundColor = Colors.orange;
      } else {
        backgroundColor = Colors.red;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$detectedCount de $totalQuestions respostas detectadas (${detectionRate.toStringAsFixed(1)}%)'),
          backgroundColor: backgroundColor,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  void _calculateAndSubmitResults() {
    if (_detectedAnswers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nenhuma resposta foi detectada. Escaneie a folha de resposta primeiro.')),
      );
      return;
    }

    if (_answerKey == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gabarito não carregado.')),
      );
      return;
    }

    // Usa o método do AnswerKey para calcular a pontuação
    Map<String, dynamic> scoreResult = _answerKey!.calculateScore(_detectedAnswers);

    final Map<String, dynamic> additionalData = {
      'correctionMethod': 'OCR',
      'detectionStats': _detectionStats,
      'recognizedText': _recognizedText,
    };

    _showResultsDialog(scoreResult, additionalData);
  }

  void _showResultsDialog(Map<String, dynamic> scoreResult, Map<String, dynamic> additionalData) {
    int correctCount = scoreResult['correctAnswers'];
    int totalQuestions = scoreResult['totalQuestions'];
    double score = scoreResult['score'];
    bool isApproved = scoreResult['isApproved'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Correção Concluída!'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Aluno: ${widget.student.name}', style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('Matrícula: ${widget.student.registration}'),
              Text('Prova: ${_answerKey!.examTitle}'),
              const SizedBox(height: 16),
              Text('Questões Corretas: $correctCount de $totalQuestions'),
              Text('Pontuação: ${score.toStringAsFixed(1)}%'),
              const SizedBox(height: 8),
              if (_detectionStats.isNotEmpty) ...[
                Text('Taxa de Detecção: ${_detectionStats['detectionRate'].toStringAsFixed(1)}%'),
                if (!_detectionStats['isComplete'])
                  Text(
                    'Questões não detectadas: ${_detectionStats['missingQuestions'].join(', ')}',
                    style: const TextStyle(color: Colors.orange, fontSize: 12),
                  ),
              ],
              const SizedBox(height: 16),
              Text(
                isApproved ? 'APROVADO' : 'REPROVADO',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: isApproved ? Colors.green : Colors.red,
                  fontSize: 18,
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Ver Detalhes'),
              onPressed: () {
                Navigator.of(context).pop();
                _showDetailedResults(scoreResult);
              },
            ),
            TextButton(
              child: const Text('Enviar Resultado'),
              onPressed: () async {
                Navigator.of(context).pop();
                await _submitEvaluation(scoreResult, additionalData);
              },
            ),
          ],
        );
      },
    );
  }

  void _showDetailedResults(Map<String, dynamic> scoreResult) {
    List<Map<String, dynamic>> detailedResults = scoreResult['detailedResults'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Detalhes da Correção'),
          content: SizedBox(
            width: double.maxFinite,
            height: 400,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Estatísticas de detecção
                  if (_detectionStats.isNotEmpty) ...[
                    Card(
                      color: Colors.blue.shade50,
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Estatísticas de Detecção:', style: TextStyle(fontWeight: FontWeight.bold)),
                            Text('Taxa: ${_detectionStats['detectionRate'].toStringAsFixed(1)}%'),
                            Text('Detectadas: ${_detectionStats['detectedCount']} de ${_detectionStats['totalQuestions']}'),
                            if (!_detectionStats['isComplete'])
                              Text('Não detectadas: ${_detectionStats['missingQuestions'].join(', ')}'),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // Sugestões
                  if (_suggestions.isNotEmpty) ...[
                    Card(
                      color: Colors.orange.shade50,
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Sugestões:', style: TextStyle(fontWeight: FontWeight.bold)),
                            ..._suggestions.map((suggestion) => Padding(
                              padding: const EdgeInsets.only(top: 4.0),
                              child: Text('• $suggestion', style: const TextStyle(fontSize: 12)),
                            )),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // Detalhes por questão
                  const Text('Detalhes por Questão:', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ...detailedResults.map((result) {
                    int questionNumber = result['questionNumber'];
                    String? correctAnswer = result['correctAnswer'];
                    String? studentAnswer = result['studentAnswer'];
                    bool isCorrect = result['isCorrect'];
                    bool wasAnswered = result['wasAnswered'];

                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Questão $questionNumber', style: const TextStyle(fontWeight: FontWeight.bold)),
                            Text('Detectado: ${studentAnswer ?? 'Não detectado'}'),
                            Text('Correto: ${correctAnswer ?? 'N/A'}'),
                            Icon(
                              wasAnswered
                                  ? (isCorrect ? Icons.check_circle : Icons.cancel)
                                  : Icons.help_outline,
                              color: wasAnswered
                                  ? (isCorrect ? Colors.green : Colors.red)
                                  : Colors.grey,
                              size: 20,
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ],
              ),
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Fechar'),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        );
      },
    );
  }

  Future<void> _submitEvaluation(Map<String, dynamic> scoreResult, Map<String, dynamic> additionalData) async {
    try {
      await ApiService.submitEvaluationWithAnswerKey(
        widget.student.id,
        _answerKey!.id,
        _detectedAnswers,
        additionalData,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Resultado enviado com sucesso!'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.of(context).pop(); // Volta para a tela anterior
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao enviar resultado: ${e.toString()}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Corrigir Prova - ${widget.student.name}'),
        actions: [
          if (_recognizedText.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.text_fields),
              onPressed: () => _showRecognizedTextDialog(),
              tooltip: 'Ver texto reconhecido',
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.assignment_outlined,
                size: 64,
                color: Colors.grey.shade400,
              ),
              const SizedBox(height: 16),
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.red, fontSize: 16),
              ),
              const SizedBox(height: 20),
              CustomButton(
                text: 'Tentar Novamente',
                onPressed: _fetchAnswerKey,
              ),
            ],
          ),
        ),
      )
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Informações do aluno e gabarito
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Aluno: ${widget.student.name}',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    Text('Matrícula: ${widget.student.registration}'),
                    const SizedBox(height: 8),
                    Text(
                      'Prova: ${_answerKey!.examTitle}',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue),
                    ),
                    Text('Total de Questões: ${_answerKey!.totalQuestions}'),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Botão para escanear
            CustomButton(
              text: _isProcessingImage ? 'Processando...' : 'Escanear Folha de Resposta',
              icon: _isProcessingImage ? null : Icons.camera_alt,
              onPressed: _isProcessingImage ? () {} : _scanAnswerSheet,
              backgroundColor: _isProcessingImage ? Colors.grey : null,
            ),

            const SizedBox(height: 20),

            // Estatísticas de detecção
            if (_detectionStats.isNotEmpty) ...[
              Card(
                color: Colors.blue.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Estatísticas de Detecção:',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text('Taxa de Detecção: ${_detectionStats['detectionRate'].toStringAsFixed(1)}%'),
                      Text('Respostas Detectadas: ${_detectionStats['detectedCount']} de ${_detectionStats['totalQuestions']}'),
                      if (!_detectionStats['isComplete'])
                        Text(
                          'Questões não detectadas: ${_detectionStats['missingQuestions'].join(', ')}',
                          style: const TextStyle(color: Colors.orange),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],

            // Sugestões
            if (_suggestions.isNotEmpty) ...[
              Card(
                color: Colors.orange.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Sugestões para Melhorar:',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      ..._suggestions.map((suggestion) => Padding(
                        padding: const EdgeInsets.only(top: 4.0),
                        child: Text('• $suggestion'),
                      )),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],

            // Imagem capturada (se houver)
            if (_capturedImage != null) ...[
              const Text(
                'Imagem Capturada:',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Container(
                height: 200,
                width: double.infinity,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.file(
                    _capturedImage!,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],

            // Respostas detectadas vs gabarito
            if (_detectedAnswers.isNotEmpty && _answerKey != null) ...[
              const Text(
                'Comparação com Gabarito:',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              ...List.generate(_answerKey!.totalQuestions, (index) {
                int questionNumber = index + 1;
                String? detectedAnswer = _detectedAnswers[questionNumber];
                String? correctAnswer = _answerKey!.answers[questionNumber];
                bool isCorrect = (detectedAnswer != null && detectedAnswer == correctAnswer);

                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  color: detectedAnswer != null
                      ? (isCorrect ? Colors.green.shade50 : Colors.red.shade50)
                      : Colors.grey.shade50,
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: detectedAnswer != null
                          ? (isCorrect ? Colors.green : Colors.red)
                          : Colors.grey,
                      child: Text('$questionNumber'),
                    ),
                    title: Text('Questão $questionNumber'),
                    subtitle: Text(
                        'Detectado: ${detectedAnswer ?? 'Não detectado'} | '
                            'Correto: ${correctAnswer ?? 'N/A'}'
                    ),
                    trailing: Icon(
                      detectedAnswer != null
                          ? (isCorrect ? Icons.check_circle : Icons.cancel)
                          : Icons.help_outline,
                      color: detectedAnswer != null
                          ? (isCorrect ? Colors.green : Colors.red)
                          : Colors.grey,
                    ),
                  ),
                );
              }),

              const SizedBox(height: 20),

              // Botão para calcular e enviar resultados
              CustomButton(
                text: 'Calcular e Enviar Resultado',
                icon: Icons.send,
                onPressed: _calculateAndSubmitResults,
                backgroundColor: Colors.green,
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showRecognizedTextDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Texto Reconhecido pelo OCR'),
          content: SizedBox(
            width: double.maxFinite,
            height: 300,
            child: SingleChildScrollView(
              child: Text(_recognizedText),
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Fechar'),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        );
      },
    );
  }
}

