// lib/screens/evaluation_screen.dart
import 'package:flutter/material.dart';
import 'package:hackathon/models/student.dart';
import 'package:hackathon/models/question.dart';
import 'package:hackathon/services/api_service.dart';
import 'package:hackathon/widgets/custom_button.dart';
import 'package:hackathon/screens/answer_sheet_correction_screen.dart'; // Nova tela de correção

class EvaluationScreen extends StatefulWidget {
  final Student student;

  const EvaluationScreen({super.key, required this.student});

  @override
  State<EvaluationScreen> createState() => _EvaluationScreenState();
}

class _EvaluationScreenState extends State<EvaluationScreen> {
  List<Question> _questions = [];
  Map<String, String?> _selectedAnswers = {}; // Map<QuestionId, AnswerOptionId>
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchQuestions();
  }

  Future<void> _fetchQuestions() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      final fetchedQuestions = await ApiService.fetchQuestions();
      setState(() {
        _questions = fetchedQuestions;
        _isLoading = false;
        for (var q in _questions) {
          _selectedAnswers[q.id] = null;
        }
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Erro ao carregar questões: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  Future<void> _submitEvaluation() async {
    bool allAnswered = true;
    _questions.forEach((q) {
      if (_selectedAnswers[q.id] == null) {
        allAnswered = false;
      }
    });

    if (!allAnswered) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, responda todas as questões antes de enviar.')),
      );
      return;
    }

    int correctAnswersCount = 0;
    List<Map<String, dynamic>> answersToSend = [];

    for (var question in _questions) {
      final selectedOptionId = _selectedAnswers[question.id];
      final isCorrect = (question.correctAnswerId != null && selectedOptionId == question.correctAnswerId);

      if (isCorrect) {
        correctAnswersCount++;
      }

      answersToSend.add({
        'questionId': question.id,
        'selectedOptionId': selectedOptionId,
        'isCorrect': isCorrect,
      });
    }

    final Map<String, dynamic> evaluationData = {
      'studentId': widget.student.id,
      'totalQuestions': _questions.length,
      'correctAnswers': correctAnswersCount,
      'score': (_questions.isNotEmpty ? (correctAnswersCount / _questions.length) * 100 : 0.0),
      'answers': answersToSend,
      'timestamp': DateTime.now().toIso8601String(),
      'correctionMethod': 'Manual', // Indica que foi corrigido manualmente
    };

    try {
      await ApiService.submitEvaluation(widget.student.id, evaluationData);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Avaliação enviada com sucesso!')),
      );

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Avaliação Concluída!'),
            content: Text(
              'Aluno: ${widget.student.name}\n'
                  'Questões Corretas: $correctAnswersCount de ${_questions.length}\n'
                  'Pontuação: ${evaluationData['score']!.toStringAsFixed(2)}%',
            ),
            actions: <Widget>[
              TextButton(
                child: const Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop(); // Fecha o diálogo
                  Navigator.of(context).pop(); // Volta para a tela de seleção de aluno
                },
              ),
            ],
          );
        },
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao enviar avaliação: ${e.toString()}')),
      );
    }
  }

  void _navigateToOCRCorrection() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AnswerSheetCorrectionScreen(student: widget.student),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Avaliar ${widget.student.name}'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.red, fontSize: 16),
              ),
              const SizedBox(height: 20),
              CustomButton(
                text: 'Tentar Novamente',
                onPressed: _fetchQuestions,
              ),
            ],
          ),
        ),
      )
          : Column(
        children: [
          // Seção de opções de correção
          Container(
            padding: const EdgeInsets.all(16.0),
            color: Colors.grey.shade100,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Escolha o método de correção:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade700,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: CustomButton(
                        text: 'Correção Automática (OCR)',
                        icon: Icons.camera_alt,
                        onPressed: _navigateToOCRCorrection,
                        backgroundColor: Colors.green,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.blue.shade200),
                        ),
                        child: Column(
                          children: [
                            Icon(Icons.edit, color: Colors.blue.shade600),
                            const SizedBox(height: 4),
                            Text(
                              'Correção Manual',
                              style: TextStyle(
                                color: Colors.blue.shade600,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            Text(
                              '(Abaixo)',
                              style: TextStyle(
                                color: Colors.blue.shade600,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Lista de questões para correção manual
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: _questions.length,
              itemBuilder: (context, index) {
                final question = _questions[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 16.0),
                  elevation: 3,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Questão ${index + 1}: ${question.text}',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        ...question.options.map((option) {
                          return RadioListTile<String>(
                            title: Text(option.text),
                            value: option.id,
                            groupValue: _selectedAnswers[question.id],
                            onChanged: (String? value) {
                              setState(() {
                                _selectedAnswers[question.id] = value;
                              });
                            },
                          );
                        }).toList(),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // Botão para enviar avaliação manual
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: CustomButton(
              text: 'Enviar Avaliação Manual',
              onPressed: _submitEvaluation,
            ),
          ),
        ],
      ),
    );
  }
}

