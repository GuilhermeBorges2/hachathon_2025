// lib/screens/evaluation_screen.dart
import 'package:flutter/material.dart';
import 'package:hackathon/models/student.dart';

class EvaluationScreen extends StatelessWidget {
  final Student student;

  const EvaluationScreen({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Avaliar ${student.name}'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Tela de Avaliação para:',
                style: TextStyle(fontSize: 20),
              ),
              SizedBox(height: 10),
              Text(
                student.name,
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              Text(
                'Matrícula: ${student.registration}',
                style: TextStyle(fontSize: 18, color: Colors.grey[700]),
              ),
              SizedBox(height: 40),
              Text(
                'Aqui você implementará a leitura via câmera ou a listagem de questões e opções de resposta.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  // TODO: Lógica para enviar as respostas para a API
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Funcionalidade de envio de avaliação em breve!')),
                  );
                },
                child: const Text('Enviar Avaliação'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

